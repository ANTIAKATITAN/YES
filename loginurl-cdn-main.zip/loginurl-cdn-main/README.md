# loginurl-cdn
Free web server including loginurl for Growtopia Private Server. It is written in NodeJS using ExpressJs.

## Deployment

You can deploy or hosting your own page in vercel.com or click this button

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/GTPSHAX/loginurl-cdn)

## Installation

1. Clone this repository
2. Run `npm install`
3. Run `node server.js`

## NOTE
- For fixing error download in Growtopia v5.07+, You need to put your cache files inside on `public/cache/`, and then change the `www.growtopia1.com` inside the OSM to your vercel domain.