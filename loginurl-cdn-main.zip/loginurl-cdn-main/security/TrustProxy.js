// importing the necessary modules

// exporting the security function
module.exports = (app) => {
    // setting the trust proxy
    app.set('trust proxy', 1);
};