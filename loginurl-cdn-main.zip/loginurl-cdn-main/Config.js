module.exports = {
    name: 'SVPS Login',   // name of the server
};
